print("Hello, Data Science!")
