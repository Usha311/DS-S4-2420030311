# WEEK 9: Probability Distributions and Statistical Hypothesis Testing
# Application: Student Exam Pass/Fail and Performance Analysis

import numpy as np
from scipy.stats import bernoulli, binom, ttest_ind
from statsmodels.stats.weightstats import ztest

# 1. Bernoulli Distribution
print("----- Bernoulli Distribution -----")
p = 0.7
samples = bernoulli.rvs(p, size=10)
print("Probability of Passing:", p)
print("Student Outcomes (1=Pass, 0=Fail):", samples)
print("Probability of Pass:", bernoulli.pmf(1, p))
print("Probability of Fail:", bernoulli.pmf(0, p))

# 2. Binomial Distribution
print("\n----- Binomial Distribution -----")
n, k = 10, 8
print("Number of Students:", n)
print("Probability of Passing:", p)
print(f"Probability that exactly {k} students pass:", binom.pmf(k, n, p))
print("Random Binomial Outcomes:", binom.rvs(n, p, size=5))

# 3. Z-Test
print("\n----- Z-Test -----")
sample_marks = np.array([78, 82, 85, 88, 90, 76, 95, 89, 84, 91])
population_mean = 80
z_stat, p_value = ztest(sample_marks, value=population_mean)
print("Sample Marks:", sample_marks)
print("Population Mean:", population_mean)
print("Z-Statistic:", z_stat)
print("P-Value:", p_value)

alpha = 0.05
print("Result:", "Reject Null Hypothesis" if p_value < alpha
      else "Fail to Reject Null Hypothesis")

# 4. Independent t-Test
print("\n----- Independent t-Test -----")
class_A = np.array([78, 82, 85, 88, 90])
class_B = np.array([72, 75, 70, 68, 74])
t_stat, p_value = ttest_ind(class_A, class_B)
print("Class A Marks:", class_A)
print("Class B Marks:", class_B)
print("t-Statistic:", t_stat)
print("P-Value:", p_value)
print("Result:", "Reject Null Hypothesis" if p_value < alpha
      else "Fail to Reject Null Hypothesis")
