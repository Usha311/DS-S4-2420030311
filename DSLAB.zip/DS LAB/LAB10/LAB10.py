# WEEK 10: Linear and Logistic Regression
# Application: House Price Prediction and Purchase Classification

import numpy as np
from sklearn.linear_model import LinearRegression, LogisticRegression

# 1. Linear Regression
print("----- Linear Regression -----")
X_linear = np.array([[1000], [1200], [1500], [1800], [2000]])
y_linear = np.array([50, 55, 65, 80, 90])  # Prices in lakhs

linear_model = LinearRegression()
linear_model.fit(X_linear, y_linear)

new_house_size = np.array([[1700]])
predicted_price = linear_model.predict(new_house_size)
print("Training House Sizes:", X_linear.flatten())
print("Training House Prices:", y_linear)
print("Predicted Price for 1700 sq.ft house:", predicted_price[0])

# 2. Logistic Regression
print("\n----- Logistic Regression -----")
X_logistic = np.array([[40], [50], [60], [70], [80], [90]])
y_logistic = np.array([0, 0, 0, 1, 1, 1])  # 0=Not Purchased, 1=Purchased

logistic_model = LogisticRegression()
logistic_model.fit(X_logistic, y_logistic)

test_price = np.array([[75]])
prediction = logistic_model.predict(test_price)
probability = logistic_model.predict_proba(test_price)

print("Training House Prices:", X_logistic.flatten())
print("Purchase Labels:", y_logistic)
print("Test House Price:", test_price[0][0])
print("Purchase Prediction:", prediction[0])
print("Prediction Probabilities:", probability)
