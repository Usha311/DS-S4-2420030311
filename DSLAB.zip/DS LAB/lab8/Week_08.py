"""
WEEK 8: Linear Algebra and Matrix Decomposition Methods
Based on DSLab_Week8.docx

Programs included:
1. LU Decomposition using Doolittle Method
2. QR Decomposition using Gram-Schmidt Method

Run in VS Code:
    python Week_08.py

Required package:
    python -m pip install numpy
"""

import numpy as np


# ------------------------------------------------------------
# 8.1 LU DECOMPOSITION USING DOOLITTLE METHOD
# Application: Solving Linear Equations Ax = b
# ------------------------------------------------------------

def lu_decomposition(A):
    n = len(A)
    L = np.zeros((n, n))
    U = np.zeros((n, n))

    for i in range(n):
        # Calculate the upper triangular matrix U
        for k in range(i, n):
            sum_upper = 0
            for j in range(i):
                sum_upper += L[i][j] * U[j][k]
            U[i][k] = A[i][k] - sum_upper

        # Calculate the lower triangular matrix L
        L[i][i] = 1
        for k in range(i + 1, n):
            sum_lower = 0
            for j in range(i):
                sum_lower += L[k][j] * U[j][i]

            if abs(U[i][i]) < 1e-12:
                raise ValueError("LU decomposition failed: zero pivot encountered.")

            L[k][i] = (A[k][i] - sum_lower) / U[i][i]

    return L, U


def forward_substitution(L, b):
    n = len(L)
    y = np.zeros(n)

    for i in range(n):
        sum_value = 0
        for j in range(i):
            sum_value += L[i][j] * y[j]
        y[i] = b[i] - sum_value

    return y


def backward_substitution(U, y):
    n = len(U)
    x = np.zeros(n)

    for i in range(n - 1, -1, -1):
        if abs(U[i][i]) < 1e-12:
            raise ValueError("Cannot solve: zero diagonal element in U.")

        sum_value = 0
        for j in range(i + 1, n):
            sum_value += U[i][j] * x[j]
        x[i] = (y[i] - sum_value) / U[i][i]

    return x


def run_lu_decomposition():
    print("=" * 60)
    print("8.1 LU DECOMPOSITION USING DOOLITTLE METHOD")
    print("=" * 60)

    A = np.array([
        [2, -1, -2],
        [-4, 6, 3],
        [-4, -2, 8]
    ], dtype=float)

    b = np.array([-2, 9, -5], dtype=float)

    L, U = lu_decomposition(A)
    y = forward_substitution(L, b)
    x = backward_substitution(U, y)

    print("Matrix A:")
    print(A)
    print("\nLower Triangular Matrix L:")
    print(L)
    print("\nUpper Triangular Matrix U:")
    print(U)
    print("\nIntermediate Solution y:")
    print(y)
    print("\nFinal Solution x:")
    print(x)


# ------------------------------------------------------------
# 8.2 QR DECOMPOSITION USING GRAM-SCHMIDT METHOD
# Application: Solving Linear System Ax = b
# ------------------------------------------------------------

def qr_decomposition(A):
    n = A.shape[0]
    Q = np.zeros((n, n))
    R = np.zeros((n, n))

    for j in range(n):
        v = A[:, j].copy()

        for i in range(j):
            R[i, j] = np.dot(Q[:, i], A[:, j])
            v = v - R[i, j] * Q[:, i]

        R[j, j] = np.linalg.norm(v)

        if abs(R[j, j]) < 1e-12:
            raise ValueError("QR decomposition failed: linearly dependent columns.")

        Q[:, j] = v / R[j, j]

    return Q, R


def solve_qr(Q, R, b):
    # Calculate Q transpose multiplied by b
    y = np.dot(Q.T, b)

    # Solve Rx = y using backward substitution
    n = R.shape[0]
    x = np.zeros(n)

    for i in range(n - 1, -1, -1):
        if abs(R[i, i]) < 1e-12:
            raise ValueError("Cannot solve: zero diagonal element in R.")

        sum_value = 0
        for j in range(i + 1, n):
            sum_value += R[i, j] * x[j]

        x[i] = (y[i] - sum_value) / R[i, i]

    return x


def run_qr_decomposition():
    print("\n" + "=" * 60)
    print("8.2 QR DECOMPOSITION USING GRAM-SCHMIDT METHOD")
    print("=" * 60)

    A = np.array([
        [1, 1, 0],
        [1, 0, 1],
        [0, 1, 1]
    ], dtype=float)

    b = np.array([4, 5, 6], dtype=float)

    Q, R = qr_decomposition(A)
    x = solve_qr(Q, R, b)

    print("Matrix A:")
    print(A)
    print("\nOrthogonal Matrix Q:")
    print(Q)
    print("\nUpper Triangular Matrix R:")
    print(R)
    print("\nSolution Vector x:")
    print(x)


# ------------------------------------------------------------
# MAIN PROGRAM
# ------------------------------------------------------------

if __name__ == "__main__":
    run_lu_decomposition()
    run_qr_decomposition()
