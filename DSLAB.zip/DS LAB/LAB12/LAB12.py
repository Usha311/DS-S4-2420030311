# WEEK 12: Unsupervised Learning
# Algorithms: K-Means and Hierarchical Clustering
# Application: Customer Segmentation

import matplotlib.pyplot as plt
from sklearn.cluster import KMeans
from sklearn.datasets import make_blobs
from scipy.cluster.hierarchy import dendrogram, linkage

# Generate a sample dataset
# Features represent two customer attributes
X, _ = make_blobs(
    n_samples=100,
    centers=3,
    cluster_std=1.5,
    random_state=42
)

# 1. K-Means Clustering
print("----- K-Means Clustering -----")
kmeans = KMeans(n_clusters=3, random_state=42, n_init=10)
kmeans.fit(X)

labels = kmeans.labels_
centers = kmeans.cluster_centers_
print("Cluster Labels:")
print(labels)
print("\nCluster Centers:")
print(centers)

plt.figure(figsize=(6, 5))
plt.scatter(X[:, 0], X[:, 1], c=labels)
plt.scatter(centers[:, 0], centers[:, 1], marker="X", s=200)
plt.title("K-Means Clustering")
plt.xlabel("Feature 1")
plt.ylabel("Feature 2")
plt.tight_layout()
plt.show()

# 2. Hierarchical Clustering
print("\n----- Hierarchical Clustering -----")
linked = linkage(X, method="ward")

plt.figure(figsize=(10, 5))
dendrogram(linked)
plt.title("Hierarchical Clustering Dendrogram")
plt.xlabel("Data Points")
plt.ylabel("Distance")
plt.tight_layout()
plt.show()
