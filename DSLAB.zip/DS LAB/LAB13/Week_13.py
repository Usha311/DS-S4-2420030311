# WEEK 13: Text Analytics and Recommendation System
# Application: Movie Recommendation
# Techniques: Text Preprocessing and Content-Based Filtering

import re
import string
import pandas as pd
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity
from nltk.tokenize import word_tokenize
from nltk.corpus import stopwords
import nltk

# Download the NLTK resources required by this program.
# These downloads are needed only the first time.
nltk.download("punkt")
nltk.download("punkt_tab")
nltk.download("stopwords")

# ---------------------------------------------------
# 1. TEXT PREPROCESSING
# ---------------------------------------------------
print("----- Text Preprocessing -----")

text = "The movie was amazing, exciting, and full of action scenes!"

# Convert text to lowercase
processed_text = text.lower()

# Remove punctuation
processed_text = processed_text.translate(
    str.maketrans("", "", string.punctuation)
)

# Tokenization
tokens = word_tokenize(processed_text)

# Stop-word removal
stop_words = set(stopwords.words("english"))
filtered_tokens = [word for word in tokens if word not in stop_words]

print("Original Text:")
print(text)
print("\\nProcessed Tokens:")
print(filtered_tokens)

# ---------------------------------------------------
# 2. CONTENT-BASED MOVIE RECOMMENDATION
# ---------------------------------------------------
print("\\n----- Content-Based Recommendation -----")

movies = pd.DataFrame({
    "Movie": [
        "Avengers",
        "Batman",
        "Superman",
        "Titanic",
        "Inception"
    ],
    "Description": [
        "action superhero marvel fight",
        "dark superhero action detective",
        "superhero flying action hero",
        "romance ship love drama",
        "dream science fiction thriller"
    ]
})

print("Movie Dataset:")
print(movies)

# Convert descriptions into TF-IDF numerical vectors
tfidf = TfidfVectorizer()
tfidf_matrix = tfidf.fit_transform(movies["Description"])

# Calculate cosine similarity between movies
similarity = cosine_similarity(tfidf_matrix)

# Choose a movie and find its index
movie_name = "Batman"
movie_index = movies[movies["Movie"] == movie_name].index[0]

# Sort movies by similarity score (highest first)
scores = list(enumerate(similarity[movie_index]))
sorted_scores = sorted(scores, key=lambda item: item[1], reverse=True)

print(f"\\nRecommended Movies for {movie_name}:")
for index, score in sorted_scores[1:4]:
    print(movies.iloc[index]["Movie"], "- Similarity:", round(score, 3))
